#include <func.h>

int main(int argc,char *argv[])
{
    execl("./add","xianghao","3","4",NULL);
    return 0;
}

